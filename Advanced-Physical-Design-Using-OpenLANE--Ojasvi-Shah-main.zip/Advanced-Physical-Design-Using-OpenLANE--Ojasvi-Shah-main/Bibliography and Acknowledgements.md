# Bibliography and Acknowledgements

## Acknowledgements

Firstly, I would like to express my heartfelt gratitude to Kunal Sir and Anagha Ma'am along with the entire VSDIAT team who has worked for this course to be accessible to me. 
I would like to thank the course instructors and the teachers for teaching with such clarity in the videos.
I would also like to thank Kunal sir for making OpenLANE and Virtual Box accessible to us for the lectures.

Secondly, I would wish to thank the entire IIITB team who conducted the various lectures throughout Level 2 and Madhav Sir. It was a truly great experience, and I really am grateful for the oppurtunity.

Thirdly, Sudarshan Sir, who devoted about 27 classes to our group, and who guided us through all the stages. It really was a great experience, and thank you so much sir for your guidance, mentorship and advice. 
Without you, this course designed for college students, probably wouldn't have been attemptable to me, a eighth grader. I really appreciate all your efforts and advice. Thank you for connecting me and the group to VSDIAT, the IIITB team and this entire opportunity on it's own.
Also, thank you for bringing the group together, I made many new friends and this definitely was an unforgettable opportunity.

## Bibliography

1. [VSDIAT platform](vsdiat.com)
2. The various sessions conducted by [Sudarshan Sir](https://www.linkedin.com/in/linkedin2sudarshan/?originalSubdomain=in)
3. Another [Repository By Deepthy Santhakumar](https://github.com/dsanthak/NASSCOM-VSD-SoC-Design)
